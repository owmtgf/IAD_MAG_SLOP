def solve(data):
    out = {}
    for line in data:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if '=' not in line:
            raise ValueError('separator')
        key,value = line.split('=')
        key,value = key.strip(),value.strip()
        if not key or key in out:
            raise ValueError('key')
        out[key] = value
    return out
