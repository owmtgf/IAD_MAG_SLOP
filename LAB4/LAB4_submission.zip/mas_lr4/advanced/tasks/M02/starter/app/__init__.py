"""Small deterministic workflow runtime."""
