"""Small synchronous order service."""
