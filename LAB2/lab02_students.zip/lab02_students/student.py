"""Реализуйте только две функции. Контракты описаны в TASK.md."""
from core import parse_action, episode


def run_agent(policy, env, max_steps=12):
    """TODO: цикл, обработка ответа, dispatch, история и остановка.

    policy.next_action(history) возвращает строку JSON.
    В history: step, raw, action (если разобран), observation.
    ValueError от parse_action: observation={ok:False,error:str(exc)};
    такой ответ расходует шаг, но env.call не вызывается.
    Ошибка policy: статус model_error, попытку также записать.
    finish(done) допустим только после актуальной успешной validation.
    Преждевременный done: observation.error='finish_without_validation', продолжить.
    finish(needs_input/no_solution) завершает цикл; правильность проверит evaluator.
    Последний допустимый finish имеет приоритет над budget_exhausted.
    Выход: core.episode(status, history, env, question).
    Не передавайте env, case или snapshot в policy.
    """
    raise NotImplementedError("TODO: run_agent")


def evaluate(result):
    """TODO: вернуть bool успеха по result['state'], статусу и вопросу.

    done: реальное допустимое предложение + актуальная положительная validation.
    needs_input: skill отсутствует, предложения нет, вопрос явно о навыке.
    no_solution: skill известен, допустимых ресурсов нет, предложения нет.
    Остальные статусы неуспешны. Не доверяйте одному флагу validation.valid.
    """
    raise NotImplementedError("TODO: evaluate")
