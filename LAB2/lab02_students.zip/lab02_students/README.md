# Практика 2 / ЛР2

Все лабораторные выполняются индивидуально. Отчёт: 1–2 страницы, максимум 2, без ФИО и раздела о вкладе.

Начните с TASK.pdf или TASK.md. Реализуйте две функции в student.py. Python 3.10+, без внешних зависимостей.

```bash
python demo.py
python -m unittest discover -s tests -p "test_support.py" -v
# После выполнения TODO:
python -m unittest discover -s tests -v
python run.py --policy scripted --split dev --out results_dev
```

Полный порядок эксперимента с LLM, контракты, критерии и сдача описаны в TASK.md. scripted проверяет механику и не является LLM-экспериментом. Формат отчёта: report_template.pdf или report_template.md. Учёт ИИ: prompts.md.
